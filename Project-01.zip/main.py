from os import path as opath
from typing import List
from sys import argv
import numpy as np
import cv2 as cv

#
def mean_kernel(size: int) -> np.ndarray:
    return np.ones((size, size), dtype=np.float32) / (size * size)

# 
def gaussian_kernel(size: int, std: float=1.0) -> np.ndarray:
    kernel = np.fromfunction(
        lambda x, y: (1 / (2 * np.pi * std ** 2)) * np.exp(
            -((x - (size - 1) / 2) ** 2 + (y - (size - 1) / 2) ** 2) / (2 * std ** 2)),
        (size, size)
    )
    return kernel / np.sum(kernel)

#
def sharpening_kernel(size: int) -> np.ndarray:
    if size == 3:
        ret = np.array([
            [ 0, -1,  0],
            [-1,  5, -1],
            [ 0, -1,  0]
        ], dtype=np.float32)
    elif size == 5:
        ret = np.array([
            [ 0,  0, -1,  0,  0],
            [ 0, -1, -1, -1,  0],
            [-1, -1, 13, -1, -1],
            [ 0, -1, -1, -1,  0],
            [ 0,  0, -1,  0,  0]
        ], dtype=np.float32)
    elif size == 7:
        ret = np.array([
            [ 0,  0,  0, -1,  0,  0,  0],
            [ 0,  0, -1, -1, -1,  0,  0],
            [ 0, -1, -1, -1, -1, -1,  0],
            [-1, -1, -1, 21, -1, -1, -1],
            [ 0, -1, -1, -1, -1, -1,  0],
            [ 0,  0, -1, -1, -1,  0,  0],
            [ 0,  0,  0, -1,  0,  0,  0]
        ], dtype=np.float32)
    elif size == 9:
        ret = np.array([
            [ 0,  0,  0,  0, -1,  0,  0,  0,  0],
            [ 0,  0,  0, -1, -1, -1,  0,  0,  0],
            [ 0,  0, -1, -1, -1, -1, -1,  0,  0],
            [ 0, -1, -1, -1, -1, -1, -1, -1,  0],
            [-1, -1, -1, -1,  35, -1, -1, -1, -1],
            [ 0, -1, -1, -1, -1, -1, -1, -1,  0],
            [ 0,  0, -1, -1, -1, -1, -1,  0,  0],
            [ 0,  0,  0, -1, -1, -1,  0,  0,  0],
            [ 0,  0,  0,  0, -1,  0,  0,  0,  0]
        ], dtype=np.float32)
    return ret / np.sum(ret)

#
def pad_image(img: np.ndarray, pad_amount: int) -> np.ndarray:
    return np.pad(
        img,
        (
            (pad_amount, pad_amount),
            (pad_amount, pad_amount),
            (0, 0)
        ),
        mode='constant'
    )

#
def median(region: np.ndarray) -> float:
    sorted_flattened = np.sort(region.flatten())
    n = len(sorted_flattened)
    if n & 0x1:
        return sorted_flattened[n // 2]
    else:
        return (sorted_flattened[n // 2 - 1] + sorted_flattened[n // 2]) / 2

#
def median_filter(img: np.ndarray, k_size: int) -> np.ndarray:
    img_height, img_width, img_channels = img.shape
    output = np.zeros_like(img, dtype=np.float32)
    img = pad_image(img, k_size // 2)

    for i in range(img_height):
        for j in range(img_width):
            region = img[i:i+k_size, j:j+k_size]
            for c in range(img_channels):
                output[i, j, c] = median(region[:, :, c])

    return output

#
def apply_filter(
    img: np.ndarray,
    kernel: np.ndarray,
    k_size: int,
    use_cv: bool) -> np.ndarray:

    if use_cv:
        return cv.filter2D(img, -1, kernel.astype(np.float32))

    img_height, img_width, img_channels = img.shape
    output = np.zeros_like(img, dtype=np.float32)
    img = pad_image(img, k_size // 2)

    for i in range(img_height):
        for j in range(img_width):
            region = img[i:i+k_size, j:j+k_size]
            for c in range(img_channels):
                output[i, j, c] = np.sum(region[:, :, c] * kernel)

    return output

#
def convolution(input_name: str, k_size: int, filters: List[str]) -> str:
    img = cv.imread(input_name, cv.IMREAD_COLOR)
    if img is None:
        return f"Image load error (cv2): \"{input_name}\"", None

    if k_size < 3 or k_size > 9:
        return f"Kernel size must be 3, 5, 7, or 9: {k_size}", None

    if not k_size & 0x1:
        return f"Even kernel size: {k_size}"

    use_cv = False
    if filters and filters[0] == "cv2":
        filters = filters[1:]
        use_cv = True
        print(" > Using cv2 filter2D.")

    if filters is None:
        return f"Add some filter strings"

    kernels = {
        "mean": mean_kernel,
        "gaussian": gaussian_kernel,
        "sharpening": sharpening_kernel
    }

    for filter in filters:
        if filter == "median":
            img = median_filter(img, k_size)
        elif filter in kernels:
            img = apply_filter(img, kernels[filter](k_size), k_size, use_cv)
        else:
            return f"Invalid kernel filter string passed: {filter}"
        print(f" > {k_size}x{k_size} {filter} filter done.")

    if use_cv:
        filters.insert(0, "cv2")
    ext = opath.splitext(input_name)
    cv.imwrite(f"{ext[0]}_{k_size}x{k_size}_{'-'.join(filters)}{ext[1]}", img)
    return None

# Program entrypoint :: - -                                                  - -
if __name__ == "__main__":
    filters = ["cv2", "median"]
    ksize = 3
    while ksize <= 9:
        ret = convolution("lena.png", ksize, filters)
        ksize += 2
        if ret:
            print(f" > {ret}")
            exit()
        print("")
        

    #ret = convolution("art.png", 9, ["cv2", "mean", "gaussian", "median"])
    #if ret: print(f" > {ret}")